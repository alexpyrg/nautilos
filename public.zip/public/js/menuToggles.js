function togglePages(){
    var pages = document.getElementById("pages");
    if(pages.classList.toggle("show"));
}

function toggleData(){
    var pages = document.getElementById("data");
    if(pages.classList.toggle("show"));
}

function toggleMailing(){
    var pages = document.getElementById("mailing");
    if(pages.classList.toggle("show"));
}

